% Function to run the original AdaBoost on multiple train/test splits
% on a given dataset under given degrees of cost imbalance
% Input arguments
%  dataset - test input in the form of matrix (#examples, #features)
%  cost_ratios - set of degrees cost imbalance to be examined
%  n_runs - number of experiments (splits & runs) 
%  weak_learner_n - maximum number of weak learners
% Output arguments
%  TP - number of true positives committed
%  FP - number of false positives committed 
%  TN - number of true negatives committed 
%  FN - number of false negatives committed
%  num_learners - actual number of weak learners added to the ensemble

function [ TP, TN, FP, FN, num_learners] = run_experiment( dataset, cost_ratios, n_runs, weak_learner_n)
cost_ratios_cpy = cost_ratios;

num_skew_ratios = length(cost_ratios);

n_methods = 4;

TP = NaN(num_skew_ratios, n_runs, n_methods);
TN = NaN(num_skew_ratios, n_runs, n_methods);
FP = NaN(num_skew_ratios, n_runs, n_methods);
FN = NaN(num_skew_ratios, n_runs, n_methods);
num_learners = NaN(num_skew_ratios, n_runs, n_methods);

%Load the dataset
eval(['load ' dataset])

%Denote negative class with -1 instead of default 0  (In multiclass 
%datasets this will also group all classes but the one with label y=1 into
%one negative class thus leading to a 1-vs-rest binary classifier):
l_vec = unique(labels); % find unigue labels
indx1 = find(l_vec==1); %find indx of class labeled with '1'
if ~isempty(indx1) %if such label '1' exists
    labels(labels==l_vec(indx1)) = 1; % pick this class as the positive class
else %if dataset contains no label '1' 
    labels(labels==l_vec(1)) = 1; % pick one of the existing labels to denote positives
end
labels(labels~=1) = -1; % group the rest of the labels as negative class)

%Compute class skew; Convention 1: c is the ratio of positives to negatives
%Convention 2: We denote by positive the rare class
initNeg_temp = sum(labels==-1);
initPos_temp = sum(labels==1);

if initPos_temp > initNeg_temp %... if +ves are less 'rare'( or 'costly') than -ves, then...
    labels = -labels; %...swap class labels; now Convention 2 is followed
    initNeg_temp = sum(labels==-1);
    initPos_temp = sum(labels==1);
end

%TEMPORARY: Change back from -1/1 to 0/1 encoding
labels(labels~=1) = 0;%TODO: Remove, encode negatives with 0 from the beginning.
labels_temp = labels;

for f = 1:num_skew_ratios %Introducing skew preserving total number of examples and equal number of examples for each class

for r=1:n_runs
 disp(['dataset = ' dataset ', skew ratio = ' num2str(cost_ratios_cpy(f)) ', run = ' num2str(r)]); 

%Flip pos/neg convention if c is less than 1
if cost_ratios(f) < 1
    labels = ~labels_temp;
    initNeg = initPos_temp;
    initPos = initNeg_temp;
    cost_ratios(f) = 1 / cost_ratios(f);
    
    %Sample initNeg negatives:
    negIndices = find(labels==0); %Identify all negative examples
    orderShuffledNeg = randperm(initNeg); %Shuffle all negative examples
    negIndices = negIndices(orderShuffledNeg(1:initNeg)); %Select the first the first initNeg (i.e. all) negative examples
    
    %Sample initNeg positives:
    posIndices = find(labels==1); %Identify all positive examples
    orderShuffledPos = randperm(initPos); %Shuffle all positive examples
    posIndices = posIndices(orderShuffledPos(1:initNeg)); %Select the first initNeg positive examples
    
else
    labels = labels_temp;
    initNeg = initNeg_temp;
    initPos = initPos_temp;
        
    %Sample initPos positives:
    posIndices = find(labels==1); %Identify all positive examples
    orderShuffledPos = randperm(initPos); %Shuffle all positive examples
    posIndices = posIndices(orderShuffledPos(1:initPos)); %Select the first initPos (i.e. all) positive examples

    %Sample initPos negatives:
    negIndices = find(labels==0); %Identify all negative examples
    orderShuffledNeg = randperm(initNeg); %Shuffle all negative examples
    negIndices = negIndices(orderShuffledNeg(1:initPos)); %Select the first initPos negative examples
end

data_used = [ data(negIndices, :) ; data(posIndices, :)];
labels_used = [ labels(negIndices) ; labels(posIndices)];
 
N = length(labels_used);
shuffledOrder = randperm(N);
data_used = data_used(shuffledOrder, :);
labels_used = labels_used(shuffledOrder);

p_test=0.25;
indx_last_test = floor(p_test*N);

data_test = data_used(1:indx_last_test, :);
labels_test = labels_used(1:indx_last_test);

data_train = data_used((indx_last_test +1):end, :);
labels_train = labels_used((indx_last_test +1):end);

%Assign importances: 
c_train = cost_ratios(f); 

%Train
disp('Training AdaBoost/AdaMEC...');
model_Ada = trainAdaBoost(data_train, labels_train, weak_learner_n);
disp('Training CGAda...');
model_CGAda = trainCGAda(data_train, labels_train, model_Ada.M, 1, c_train);%'model_Ada.M' for equal number of weak learners else 'weak_learner_n'
disp('Training AsymAda...');
model_AsymAda = trainAsymAda(data_train, labels_train, model_Ada.M, 1, c_train);%'model_Ada.M' for equal number of weak learners else 'weak_learner_n'

%Evaluate: Store number of TP, FP, TN, FN on test set, as well as the number of learners used in the ensemble:
  %Original AdaBoost:
    [TP(f, r, 1), FP(f, r, 1), TN(f, r, 1), FN(f, r, 1)] = returnContigencyTable(model_Ada, data_test, labels_test);
  %AdaMEC:
    [TP(f, r, 2), FP(f, r, 2), TN(f, r, 2), FN(f, r, 2)] = returnContigencyTableMEC(model_Ada, data_test, labels_test, 1, c_train );
  %CGAda:
    [TP(f, r, 3), FP(f, r, 3), TN(f, r, 3), FN(f, r, 3)] = returnContigencyTable(model_CGAda, data_test, labels_test);
  %AsymAda:
    [TP(f, r, 4), FP(f, r, 4), TN(f, r, 4), FN(f, r, 4)] = returnContigencyTable(model_AsymAda, data_test, labels_test);
    
  %Store number of learners:
    num_learners(f, r, 1) = model_Ada.M;
    num_learners(f, r, 2) = model_Ada.M;
    num_learners(f, r, 3) = model_CGAda.M;
    num_learners(f, r, 4) = model_AsymAda.M;

% Clear models
clear model_Ada;
clear model_Ada;
clear model_AsymAda;

end % end run loop

end % end skew ratios tested loop

end

