The present code can be used for executing and comparing the folowing AdaBoost variants:
AdaBoost (original algorithm)
AdaMEC   (threshold-shifted AdaBoost)
CGAda    (AdaBoost with cost-proportional initial weights)
AsymAda  (AdaBoost with cost-sensitive training)
in both their calibrated and uncalibrated versions,
on multiple train/test splits on a given list of datasets, under a given
set of degrees of cost imbalance (all can be modified by the user).

The file named 'setup_experiments.m' is the main script. It runs the
specified experiments and generates the result files.

After generating the result files, the user can call 'visualize.m' to 
plot loss-vs-skew or compute some other evaluation measure.

For more details consult the extensive comments inside each file.
