% Function to compute contigency table (confusion matrix) for 
% calibrated methods that do not apply threshold shifting
% Input arguments
%  model - a boosting ensemble as produced by e.g. trainAdaBoost.m 
%  x - test input in the form of matrix (#examples, #features)
%  y - vector of class labels 0/1
%  cFP - cost of committing a false positive
%  cFN - cost of committing a false negative
%  A_fit - optimal parameters for the logistic sigmoid as produced by
%          platt_scaling.m, used to calibrate the scores
% Output arguments
%  TP - number of true positives committed
%  FP - number of false positives committed 
%  TN - number of true negatives committed 
%  FN - number of false negatives committed

function [TP, FP, TN, FN] = returnContigencyTable_CALIBRATION(model, x, y, ~, ~, A_fit)
[cl, ~] = predictAdaMEC_CALIBRATED(x, model, 1, 1, A_fit);%Sets cFP = cFN = 1 to always have a threshold of 0.5 (no shift)

TP = sum((y==1).*(cl==1));
FP = sum((y==0).*(cl==1));
TN = sum((y==0).*(cl==0));
FN = sum((y==1).*(cl==0));
