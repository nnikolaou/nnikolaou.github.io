% A script to be used for plotting average cost-sensitive loss -vs- skew
% and 95% confidence intervals. The script uses the result files generated
% by setupExperiments.m. 


close all;
clear all;
clc; 

%datasets =  {'survival', 'ionosphere', 'congress_orig', 'liver', 'pima', 'parkinsons',...
%           'landsatM', 'krvskp', 'heart_orig', 'wdbc_orig', 'german_credit', 'sonar_orig',...
%           'semeion_orig', 'spliceM', 'spambase', 'waveformM', 'musk2', 'mushroom'};


dataset = 'heart_orig';

if strcmp(dataset, 'wdbc_orig')
    datname2 = 'wdbc';
elseif strcmp(dataset, 'heart_orig')
    datname2 = 'heart';
elseif strcmp(dataset, 'semeion_orig')
    datname2 = 'semeion';
elseif strcmp(dataset, 'sonar_orig')
    datname2 = 'sonar';
elseif strcmp(dataset, 'congress_orig')
    datname2 = 'congress';
elseif strcmp(dataset, 'landsatM')
    datname2 = 'landsat';
elseif strcmp(dataset, 'german_credit')
    datname2 = 'credit';
elseif strcmp(dataset, 'spliceM')
    datname2 = 'splice';
elseif strcmp(dataset, 'waveformM')
    datname2 = 'waveform';
else
    datname2 = dataset;
end

load([pwd, '\Results_Uncalibrated_', datname2,'.mat'])
%std_q = zeros(size(std_q));
avg_q
last = length(c);

skew = ones(size(FN));
for i=1:length(c)
    skew(i,:,:) = c(i) ./ (c(i) + 1); % calculate skew (here assuming equal class priors)
end
errorbar(skew(1:last,1),avg_q(1:last,1),(std_q(1:last,1) / sqrt(n_runs))*tinv(0.975,(n_runs-1)),'-b','MarkerSize',25,'LineWidth',2.5)%AdaBoost
hold on
errorbar(skew(1:last,1),avg_q(1:last,2),(std_q(1:last,2) / sqrt(n_runs))*tinv(0.975,(n_runs-1)),'-g','MarkerSize',25,'LineWidth',2.5)%AdaMEC
%errorbar(skew(1:last,1),avg_q(1:last,3),(std_q(1:last,3) / sqrt(n_runs))*tinv(0.975,(n_runs-1)),'-r','MarkerSize',25,'LineWidth',2.5)%CGAda
%errorbar(skew(1:last,1),avg_q(1:last,4),(std_q(1:last,4) / sqrt(n_runs))*tinv(0.975,(n_runs-1)),'-k','MarkerSize',25,'LineWidth',2.5)%AsymAda

load([pwd, '\Results_Calibrated_', datname2,'.mat'])
%std_q = zeros(size(std_q));
avg_q
skew = ones(size(FN));
for i=1:length(c)
    skew(i,:,:) = c(i) ./ (c(i) + 1); % calculate skew (here assuming equal class priors)
end
%errorbar(skew(1:last,1),avg_q(1:last,1),(std_q(1:last,1) / sqrt(n_runs))*tinv(0.975,(n_runs-1)),'--b*','MarkerSize',25,'LineWidth',2.5)%Calibrated AdaBoost
errorbar(skew(1:last,1),avg_q(1:last,2),(std_q(1:last,2) / sqrt(n_runs))*tinv(0.975,(n_runs-1)),'--g*','MarkerSize',25,'LineWidth',2.5)%Calibrated AdaMEC
%errorbar(skew(1:last,1),avg_q(1:last,3),(std_q(1:last,3) / sqrt(n_runs))*tinv(0.975,(n_runs-1)),'--r*','MarkerSize',25,'LineWidth',2.5)%Calibrated CGAda
%errorbar(skew(1:last,1),avg_q(1:last,4),(std_q(1:last,4) / sqrt(n_runs))*tinv(0.975,(n_runs-1)),'--k*','MarkerSize',25,'LineWidth',2.5)%Calibrated AsymAda
hold off
xlabel('Skew z','FontSize',20)
ylabel('Loss Q(z)','FontSize',20)
legend('AdaBoost', 'AdaMEC', 'CGAda', 'AsymAda', 'AdaBoost-Cal', 'AdaMEC-Cal', 'CGAda-Cal', 'AsymAda-Cal','Location','NorthEast')
title(datname2,'FontSize',20)
xlim([0 1])
ylim([0 1])
set(gca,'fontsize',20)