% Function to train an Adaboost ensemble
% I/P arguments
%  x - input data in the form of matrix
%  y - vector of class labels 0/1
%  M - number of learners required
%  cFP - cost of a false positive (importance of a negative)
%  cFN - cost of a false negative (importance of a positive)
% O/P parameters
%  model - a structure of the learned model which consists of
%    hyp - the hypothesis/weak learner
%    alpha - weight associated with the learned hypothesis

function [model] = trainAsymAda(x, y, M, cFP, cFN)

%Rescale cost-matrix:
if cFP ~=1
    cFP = 1;
    cFN = cFN/cFP;
end

%Rescale cFN to evenly distribute cost among M weak learners: [AsymAda differs from original AdaBoost here!]
cFN = (cFN)^(1/M);

% Count number of examples:
[N, ~] = size(x);

% Assign a cost to each training example. [AsymAda differs from original AdaBoost here!]
costs = ones(N,1).*(y==1)*cFN; %Cost is cFN for positive examples...
costs(costs==0) = cFP; %Cost is  cFP for negative examples...

% Weight distribution over the training examples. Initially it is uniform.
weights = ones(N,1) ./ N;

%Initializing the error rate (of the 0-th weak learner) to < 0.5 (to enter
%the while loop for the 1st iteration)
%epsilon = 0.45;
%nepsilon = 0.55;
alpha = 1;

i=1;
while(i <= M && alpha > 0 && alpha < inf)%(i <= M && nepsilon > epsilon)%(i <= M && epsilon < 0.5 && epsilon > 0)
    %Train the i-th weak learner.
    %The 2nd argument of [logreg_tr] is the weight distribution over
    %the training examples. Initially this is uniform.
    model.hyp(i) = logreg_tr(x, weights, y);
    
    %Obtain the predictions from the i-th weak learner (predcl: predicted
    %class, the ommitted arguments are, respectively, p0: probability
    %estimate of p(y | x ; h_i), p1 = 1 - p0.
    %In the future: We can use these to implement RealBoost.
    %For now: In Adaboost, the weak learners output hard predictions. 
    [predcl, ~, ~] = logreg_te(x,model.hyp(i));

    %Flag the misclassified examples with '1' (correct with '0').
    nh = (predcl==1).*(y == 0) + (predcl==0).*(y == 1);
    
    %epsilon is the sum of weights corresponding to examples that were
    %misclassified by the i-th expert multiplied by the cost of the
    %examples(the weighted - by example weight and class importance - error
    %rate of the i-th expert). Respectively, nepsilon is the sum of weights
    %corresponding to examples that were correctly classified by the i-th expert
    %multiplied by the cost of the examples [AsymAda differs from original AdaBoost here!]
    epsilon = sum(costs.*weights.*nh);
    nepsilon = sum(costs.*weights.*(~nh));
    
    %The confidence of the i-th model (its contribution in the ensemble) [AsymAda differs from original AdaBoost here!]
    alpha = 0.5*log((nepsilon)/epsilon);
    
    %If the i-th model has an error greater than 0.5...
    if (alpha < 0)%(nepsilon < epsilon)%(epsilon > 0.5)
        %...then flip predictions to obtain a learner with error < 0.5
        %(do this by using the negative of the weights for the i-th learner
        %we calculated earlier in logreg_te())
        model.hyp(i).w = -model.hyp(i).w;
        
        %Obtain the predictions from the i-th weak learner (predcl:
        %predicted class, the ommitted arguments are, respectively,
        %p0: probability estimate of p(y | x ; h_i), p1 = 1 - p0.
        %In the future: We can use these to implement RealBoost.
        %For now: In Adaboost, the weak learners output hard predictions.
        [predcl, ~, ~] = logreg_te(x,model.hyp(i));
        
        %Flag the misclassified examples with '1' (correct with '0').
        nh = (predcl==1).*(y == 0) + (predcl==0).*(y == 1);
        
        %epsilon is the sum of weights corresponding to examples that were
        %misclassified by the i-th expert multiplied by the cost of the
        %examples(the weighted - by example weight and class importance - error
        %rate of the i-th expert). Respectively, nepsilon is the sum of weights
        %corresponding to examples that were misclassified by the i-th expert
        %multiplied by the cost of the examples [AsymAda differs from original AdaBoost here!]
        epsilon = sum(costs.*weights.*nh);
        nepsilon = sum(costs.*weights.*(~nh));
        
        %The confidence of the i-th model (its contribution in the ensemble) [AsymAda differs from original AdaBoost here!]
        alpha = 0.5*log((nepsilon)/epsilon);
    end;
    
    %After this line nh will store the vector of -y_n*h_{i}(x_n) (i.e.
    %'1' if n is misclassified by the i-th weak learner and '-1' otherwise)
    nh(nh==0) = -1;
    
    %Update weights [AdaC2 differs from original AdaBoost here!]
    weights = costs.*weights.*exp(alpha*nh);%Weight of each example n is multiplied by e^{-\alpha_i*y_n*h_{i}(x_n)} but also by its cost.
    weights = weights./sum(weights);%Renormalize weights to add up to 1
    
    model.alpha(i) = alpha;%Store the confidence of the i-th weak learner
    
    i = i + 1;%increase weak learner count
end;
model.M = i - 1;% Correct count of weak learners (We start with 1 learner
%in the ensemble, so the i-th iteration of the while loop corresponds to
%the (i+1)-th learner added to the ensemble)

