% Function to predict the class label for a given learned model and a test
% input, with cost-sensitive threshold shifting applied to the decision
% Input arguments
%  x - test input in the form of matrix (#examples, #features)
%  model - a boosting ensemble as produced by e.g. trainAdaBoost.m
%  cFP - cost of committing a false positive
%  cFN - cost of committing a false negative
% Output arguments
%  H - predicted class label 0/1

function [H, scores] = predictAdaMEC(x, model, cFP, cFN)

%Count number of examples
[N, ~] = size(x);
scores = zeros(N,1);%Vector of scores
sum_alphas=0;

for i = 1:model.M %Loop through all learners
    % Predictions by the i-th weak learner
    [~, p0, p1] = logreg_te(x,model.hyp(i));
    % Predicted class cl is encoded as...
    cl = ones(N,1).*(p1>p0);%...'1' if p1>p0 and '0', otherwise

    scores = scores + cl*model.alpha(i);
    sum_alphas = sum_alphas + model.alpha(i);
end;

%Score for each example is fraction of alphas assigned to positive class:
scores = scores./sum_alphas;

%Optimal threshold for minimizing expected cost under known costs cFP, cFN:
t = cFP / (cFN+cFP);

%Final ensemble classification of AdaMEC (original AdaBoost ignores cFP, cFN and sets t = 0.5)
H = (scores > t);