% Function to predict the class label for a given learned model and a test input
% Input arguments
%  x - test input in the form of matrix (#examples, #features)
%  model - a boosting ensemble as produced by e.g. trainAdaBoost.m
% Output arguments
%  H - predicted class label 0/1
%  scores - score for the positive class, for each example in x

function [H, scores] = predictAdaBoostWithScores(x, model)

%Count number of examples
[N, ~] = size(x);
scores = zeros(N,1);%Vector of scores
sum_alphas=0;

%Vector of final class predictions
H = zeros(N,1);

for i = 1:model.M %Loop through all learners
    % Predictions by the i-th weak learner
    [~, p0, p1] = logreg_te(x,model.hyp(i));
    % Predicted class cl is encoded as...
    cl = ones(N,1).*(p1>p0);%...'1' if p1>p0...

    scores = scores + cl*model.alpha(i);
    sum_alphas = sum_alphas + model.alpha(i);
    
    cl(cl==0) = -1;%now encode class '0' as '-1' to simplify algebra
    
    % Aggregate the pregictions cl of each base learner weighted by their
    % confidence (alpha(i) for i-th weak learner) into final prediction H:
    H = H + cl*model.alpha(i);   
end;

H(H > 0)=1;  %Final ensemble classifies example to '1' if H > 0...
H(H <= 0)=0; %...else to '0'

%Score for each example is the fraction of alphas assigned to positive class:
scores = scores./sum_alphas;