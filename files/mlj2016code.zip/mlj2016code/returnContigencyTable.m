% Function to compute contigency table (confusion matrix) AdaBoost
% Input arguments
%  model - an AdaBoost ensemble as produced by trainAdaBoost.m
%  x - test input in the form of matrix (#examples, #features)
%  y - vector of class labels 0/1
% Output arguments
%  TP - number of true positives committed
%  FP - number of false positives committed 
%  TN - number of true negatives committed 
%  FN - number of false negatives committed

function [TP, FP, TN, FN] = returnContigencyTable(model, x, y)
[cl,~] = predictAdaBoostWithScores(x,model);

TP = sum((y==1).*(cl==1));
FP = sum((y==0).*(cl==1));
TN = sum((y==0).*(cl==0));
FN = sum((y==1).*(cl==0));
