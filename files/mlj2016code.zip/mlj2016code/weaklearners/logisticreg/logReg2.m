% Performs a single step scaled conjugate gradient descent for a univariate 
% weighted logistic regression model
% I/P arguments
%  x - input variable
%  y - output class labels
%  wt - weight on the data points
% O/P arguments
%  w - the optimised parameters (slope, intercept)
%  err - the error in regression for the parameter w
function [w err] = logReg2(x,y,wt)
options = foptions();
options(14) = 10;
options(1) = -1;
%w = [1 0];
w = rand(1,2);

w = scg(@fn,w,options,@gradfn,x,y,wt);
err = fn(w,x,y,wt);

% The error function
function val = fn(w,x,y,weight)
[N D] = size(x);
x = [x ones(N,1)];
z = x*w';
p1 = exp(z)./(exp(z) + 1);
p0 = 1 - p1;
ph = y.*p1 + (1-y).*p0;
indlt = (ph <= 0.5);
indgt = (ph > 0.5);
a = sum(weight.*indlt.*(2*ph-1));
b = sum(weight.*indlt.*(ph - 1));
c = sum(weight.*indgt.*ph);
val = a/(2*b - 2*c + 1);

% Gradient of the error function
function dw = gradfn(w,x,y,weight)
[N D] = size(x);
xd = [x ones(N,1)];
z = xd*w';

%optimization of lines below
expz = exp(z);

p1 = expz./(expz + 1);
p0 = 1 - p1;

dp1(:,1) = (expz./(expz + 1) - (expz.*expz)./((expz+1).^2)).*x;
dp1(:,2) = (expz./(expz + 1) - (expz.*expz)./((expz+1).^2));
dp0(:,1) = -(expz./((expz + 1).^2)).*x;
dp0(:,2) = -(expz./((expz + 1).^2));

%ORIGINAL LINES
% p1 = exp(z)./(exp(z) + 1);
% p0 = 1 - p1;
% dp1(:,1) = (exp(z)./(exp(z) + 1) - exp(2*z)./((exp(z)+1).^2)).*x;
% dp1(:,2) = (exp(z)./(exp(z) + 1) - exp(2*z)./((exp(z)+1).^2));
% dp0(:,1) = -(exp(z)./((exp(z) + 1).^2)).*x;
% dp0(:,2) = -(exp(z)./((exp(z) + 1).^2));


ph = y.*p1 + (1-y).*p0;
dph(:,1) = y.*dp1(:,1) + (1-y).*dp0(:,1);
dph(:,2) = y.*dp1(:,2) + (1-y).*dp0(:,2);

indlt = (ph < 0.5);
indgt = (ph >= 0.5);

b = sum(weight.*indlt.*(ph - 1));
b1 = 2*sum(weight.*indlt.*dph(:,1));
b2 = 2*sum(weight.*indlt.*dph(:,2));

c = sum(weight.*indgt.*ph);
c1 = 2*sum(weight.*indgt.*dph(:,1));
c2 = 2*sum(weight.*indgt.*dph(:,2));

a = sum(weight.*indlt.*(2*ph-1));
a1 = 2*sum(weight.*indlt.*dph(:,1));
a2 = 2*sum(weight.*indlt.*dph(:,2));

%further optimization of lines below
 denom = (2*b - 2*c + 1);
 denomsq = denom^2;
 dw = ([a1 a2]*denom - a*[(b1-c1) , (b2-c2)]) ./ denomsq;
% 
% %%tmp1 = (  a1*denom );
% %%tmp1 = tmp1 - a*b1 + a*c1;
% %%tmp1 = tmp1 - a*(b1 - c1);
% %%tmp1 = tmp1 / denomsq;
% 
% 
% %%dw = ([a1;a2]*denom - a*[b1-c1]) . /denomsq;
% 
% % tmp1 = (  a1*denom  );
% % tmp1 = tmp1 - a*b1 + a*c1;
% % 
% % tmp2 = (  a2*denom - a*b2 + a*c2  );
% % 
% % dw(1) = tmp1;
% % dw(2) = tmp2;
% % dw = dw ./denomsq;
% 
% %optimization of lines below
% %denom = (2*b - 2*c + 1);
% %dw(1) = a1/denom - a*(b1 - c1)/(denom^2);
% %dw(2) = a2/denom - a*(b2 - c2)/(denom^2);
% %input('new')

%original lines
%dw(1) = a1/(2*b - 2*c + 1) - a*(b1 - c1)/((2*b -2*c + 1)^2);
%dw(2) = a2/(2*b - 2*c + 1) - a*(b2 - c2)/((2*b -2*c + 1)^2);

