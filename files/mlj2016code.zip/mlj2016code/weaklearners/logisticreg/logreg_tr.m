% Function that learns a weak univariate logistic regression
% I/P arguments
%  x - input data
%  weights - weights on the data instances
%  y - class labels
% O/P argument
%  hyp - structure corresponding to hypothesis with fields
%   dim - the dimension of x used for regression
%   w - the [slope intercept] vector
function hyp = logreg_tr(x, weights, y)
[N D] = size(x);
value = 1e130;

% finds the dimension that gives the smallest error
for dim = 1:D
    % logistic regression on dimension dim
    [w tmp_value] = logReg2(x(:,dim),y,weights);

    % if current error is less than the previous
    if (tmp_value < value)
        value = tmp_value;
        hyp.dim = dim;
        hyp.w = w;
    end;
end;
