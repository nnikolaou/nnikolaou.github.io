% Function that predicts the class and class probablities for a given input
% query point.
% I/P arguments
%  x - input data
%  hyp - structure corresponding to hypothesis
% O/P argument
%  cl - class label
%  p0 - probability of class 0
%  p1 - probability of class 1
function [cl p0 p1] = logreg_te(x,hyp)
[N D] = size(x);
if (isempty(hyp.dim))
    cl = ones(N,1);
    p0 = 0.5*ones(N,1);
    p1 = 1 - p0;
    return;
end;
xt = [x(:,hyp.dim) ones(N,1)];
w = hyp.w;
z = xt*w';
p1 = exp(z)./(exp(z) + 1);
p0 = 1 - p1;
cl = (p1 > p0);