% Function to calibrate the outputs of a model via Platt Scaling 
% Input arguments
%  model - an AdaBoost ensemble as produced by trainAdaBoost.m
%  x - input data in the form of matrix (#examples, #features)
%  y_orig - vector of class labels 0/1
% Output parameters
%  A_fit - parameter vector of the logistic sigmoid fit

function [ A_fit ] = platt_scaling(model, x, y_orig)

[~, s] = predictAdaBoostWithScores(x, model);%s stores the scores

%Class imbalance correction (replace 0/1 labels with ''soft'' versions) as
%detailed in: Platt, J., "Probabilistic outputs for support vector machines
%and comparisons to regularized likelihood methods", Advances in large
%margin classifiers 10 (3): 61�74, 1999.
y_new = zeros(size(y_orig));
Npos = sum(y_orig==1);
Nneg = sum(y_orig==0);
y_plus = (Npos+1) / (Npos+2);
y_minus = 1 / (Nneg+2);
y_new(y_orig==1) = y_plus;
y_new(y_orig==0) = y_minus;


%Mean Squared Error Estimation
sigfunc = @(A, x)(1 ./ (1 + exp(A(1)*x+ A(2))));% Function to be fitted (here:  logistic sigmoid, A: the parameter vector)
A0 = ones(1,2); % Initial values of parameters

options = statset('MaxIter', 600, 'TolFun', 1e-10); % Fitting hyperparameters (MaxIter: maximum no of iterations, TolFun: Residual error to be tolerated )
A_fit = nlinfit(s, y_new, sigfunc, A0, options); % Find optimal parameters for the sigmoid

end

