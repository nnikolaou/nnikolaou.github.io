% A script to be used for comparing the folowing AdaBoost variants:
% AdaBoost (original algorithm)
% AdaMEC   (threshold-shifted AdaBoost)
% CGAda    (AdaBoost with cost-proportional initial weights)
% AsymAda  (AdaBoost with cost-sensitive training)
% in both their calibrated and uncalibrated versions,
% on multiple train/test splits on a given list of datasets, under a given
% set of degrees of cost imbalance.
% After generating the result files, the user can call visualize.m to 
% plot loss-vs-skew or compute some other evaluation measure.

% Parameters to be set in this script:
%  dataset_list - list of datasets to be used in experiments
%  c - set of degrees of cost ratios C_FN / C_FP to be examined
%  n_runs - number of experiments (splits & runs) 
%  weak_learner_n - maximum number of weak learners (default: same for all)

% Output of this script:
%  A result file named after the dataset and method including:
%    avg_q - average cost sensitive loss 
%    std_q - standard deviation of cost sensitive loss 
%    TP - number of true positives committed
%    FP - number of false positives committed 
%    TN - number of true negatives committed 
%    FN - number of false negatives committed
%    num_learners - actual number of weak learners added to the ensemble

% More details on current version - The user is encouraged to experiment
% with the following settings:
%  Univariate logistic regression trained via conjugate gradient descent
%    is used as the base learner.
%  Score for the positive class is calculated as the fraction of voting
%    weights of the ensemble assigned to the positive class.
%  Scores are calibrated via Platt Scaling on a separate calibration set,
%    consisting of 3/8ths of the training data (the other 3/8ths are used
%    for training the model and the remaining 1/4th for testing).
%  The datasets included are taken from the UCI repository, multiclass
%    datasets were transformed to binary via a 1-vs-rest transformation
%    (positive class is the one specified in the description of the dataset
%    as ''important'', otherwise the minority class) , mising entries were
%    dropped.
%  Experiments are run using an equal number of positives and negatives
%    (before train\test\calibration split). This is done by undersampling
%    majority class.


close all;
clear all;
clc;

%Add the following to the matlab path: 
addpath(genpath('clean datasets/'))% Datasets (Modified from UCI, binarized, mising entries dropped)
addpath(genpath('utils/')); %We use cgd from netlab toolbox (included) to train weak learner
addpath(genpath('weaklearners/')); % Code for weak learner training and prediction 

% Datasets to be used:
dataset_list = {'heart_orig'}; %{'survival', 'ionosphere', 'congress_orig', 'liver', 'pima', 'parkinsons',...
                %'landsatM', 'krvskp', 'heart_orig', 'wdbc_orig', 'german_credit', 'sonar_orig',...
                %'semeion_orig', 'spliceM', 'waveformM', 'spambase', 'musk2', 'mushroom'};

% Cost ratios to be examined:            
c = [1/100, 1/20, 1/5, 1, 5, 20, 100];%[1/100, 1/50, 1/25, 1/20, 1/15, 1/10, 1/5, 1/2.5, 1/2, 1/1.5, 1, 1.5, 2, 2.5, 5, 10, 15, 20, 25, 50, 100]; % cost ratios to be examined
c_eff = max([c; 1./c]); %cost(expensive)/cost(cheap)

%Number of experiments (splits & runs)
n_runs = 10;%30;

%Maximum number of weak learners
weak_learner_n = 40;%100; 

for d = 1:length(dataset_list)
    dataset = char(dataset_list(d));
    
    disp('Training uncalibrated boosting ensembles:')
    [ TP, TN, FP, FN, num_learners ] = run_experiment( dataset, c, n_runs, weak_learner_n );
    
    %Evaluation
    skew = ones(size(FN));
    for i=1:length(c)
        skew(i,:,:) = c_eff(i) ./ (c_eff(i) + 1); % calculate skew
    end
   
    q  = (FN ./ (FN + TP)) .*skew + (FP ./ (FP + TN)).*(1-skew);% Compute cost-sensitive loss
    avg_q  = nanmean(q, 2);
    avg_q  = reshape(avg_q (:, :), size(avg_q, 1), size(avg_q, 3));
    std_q  = nanstd(q, 1, 2);
    std_q  = reshape(std_q (:, :), size(std_q, 1), size(std_q, 3));
    
    %Save results:
    save([pwd '/Results_Uncalibrated_', dataset])
    disp(['RESULT FILE GENERATED: Results_Uncalibrated_', dataset]);
        
    disp('Training calibrated boosting ensembles:')
    [ TP, TN, FP, FN, num_learners ] = run_experiment_with_CALIBRATION( dataset, c, n_runs, weak_learner_n );
    
    %Evaluation
    skew = ones(size(FN));
    for i=1:length(c)
        skew(i,:,:) = c_eff(i) ./ (c_eff(i) + 1); % calculate skew
    end
   
    q  = (FN ./ (FN + TP)) .*skew + (FP ./ (FP + TN)).*(1-skew);% Compute cost-sensitive loss
    avg_q  = nanmean(q, 2);
    avg_q  = reshape(avg_q (:, :), size(avg_q, 1), size(avg_q, 3));
    std_q  = nanstd(q, 1, 2);
    std_q  = reshape(std_q (:, :), size(std_q, 1), size(std_q, 3));
    
    %Save results:
    save([pwd '/Results_Calibrated_', dataset])
    disp(['RESULT FILE GENERATED: Results_Calibrated_', dataset]);
 
    
end %end datasets loop